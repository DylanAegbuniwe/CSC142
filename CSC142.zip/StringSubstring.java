public class StringSubstring {
  public static void main(String [] args) {
String t = "hee dee hee dee hee dee hee"; 
int x = t.indexOf("dee"); 
String u = t.substring(0,x); 
      u = u + " haw";
  }
}
