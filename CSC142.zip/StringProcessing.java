public class StringProcessing {
  public static void main(String [] args) {
    String s = "Ships at a distance have every man's wish on board.";
    int spacePos1 = 0;
    int spacePos2 = s.indexOf(" ");
    String hyphenated = "";
    while(spacePos2>=0) {
      String word = s.substring(spacePos1,spacePos2);
      hyphenated = hyphenated + word + "-";
      spacePos1 = spacePos2 + 1;
      spacePos2 = s.indexOf(" ", spacePos1);
    }
    if(spacePos1<s.length()) {
      hyphenated = hyphenated + s.substring(spacePos1, s.length());
    }
  }
}
