public class Person{
private int age;
private String name;
public Person(String a, int g){
name = a;
age = g;
}

public String toString(){
   return "N("+name+"),A("+age+"),";
}

public String getName(){return name;}

public boolean has_same_name(Person right){
   if(name==null) return false;
   return name.equals(right.getName());
}

public boolean has_same_age(Person right){
   return age == right.getAge();
}
 
public int getAge(){return age;}
 
public boolean is_younger_than(Person right){
   return age < right.getAge();
}

public boolean is_older_than(Person right){
   return age > right.getAge();
}

} 
