public class Time
{
   private int hour;
   private int minute;
   public Time()
   {
      hour = 0;
      minute = 0;
   }
   public String toString()
   {
      return ("(" + hour + ", " + minute + ")");
   }
   public int getHour()
   {
      return hour;
   }
   public int getMinute()
   {
      return minute;
   }
   public boolean isValid(int x, int y)
   {
      if (((x <= 11) && (x >= 0)) && ((y <= 59) && (y >= 0)))
      {
         return true;
      }
      return false;
   }
   public void setTime(int x, int y, boolean isAm)
   {
      if (isAm == false)
      {
         x += 12;
      }
      hour = x;
      minute = y;
   }
   public int compareTo(Time x)
   {
      if (hour > x.getHour())
      {
         return 1;
      }
      if (hour < x.getHour())
      {
         return -1;
      }
      if (hour == x.getHour())
      {
         if (minute > x.getMinute())
         {
            return 1;
         }
         if (minute < x.getMinute())
         {
            return -1;
         }
      }
      return 0;
   }
}