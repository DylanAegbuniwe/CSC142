public class TestScores
{
   private double score1;
   private double score2;
   private double score3;
   private double avg;
   public TestScores(int[] a)
   {
      score1 = a[0];
      score2 = a[1];
      score3 = a[2];
      avg = ((score1+score2+score3)/3);
   }
   public TestScores(int a, int b, int c)
   {
      score1 = a;
      score2 = b;
      score3 = c;
      avg = ((score1+score2+score3)/3);
   }
   public double getAvg()
   {
      return avg;
   }
   public String toString()
   {
      return Double.toString((score1+score2+score3)/3);
   }
   public int compareTo(TestScores a)
   {
      if (avg > a.getAvg())
      {
         return 1;
      }
      if (avg < a.getAvg())
      {
         return -1;
      }
      return 0;      
   }
}