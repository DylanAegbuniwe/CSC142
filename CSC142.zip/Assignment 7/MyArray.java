import java.util.*;
public class MyArray
{
   private int[] head;
   public boolean add(int x, int y)
   {
      int h = 0, c = 0;
      if (head == null)
         h = 0;
      else
      {
         h = head.length;
      } 
      if (x > h)
         return false;
      else
      {    
         ArrayList<Integer> w = new ArrayList<>();
         int[] z = new int[h+1];
         for (c = 0; c < h; c++)
         {
            w.add(head[c]);
         } 
         w.add(head[h-1]);
         for (c = 0; c < (h+1); c++)
         {
            z[c] = w.get(c);
         }
         for (c = h; c >= x; c--)
         {
            if (c != 0)
               z[c] = head[c-1];   
         }
         z[x] = y;
         head = z;
         return true;
      }
   }
   public void add(int x)
   {
      int h = 0, c = 0;
      if (head == null)
         h = 0;
      else
      {
         h = head.length;
      }   
      ArrayList<Integer> y = new ArrayList<>();
      int[] z = new int[h+1];
      for (c = 0; c < h; c++)
      {
         y.add(head[c]);
      } 
      y.add(x);
      for (c = 0; c < (h+1); c++)
      {
         z[c] = y.get(c);
      }
      head = z;
   }
   public String toString()
   {
      return (Arrays.toString(head));
   }
   public void remove()
   {
      if (head != null)
      {
         int[] x = new int[head.length-1];
         for (int c = 0; c < (head.length-1); c++)
         {
            x[c] = head[c+1];   
         }
         head = x;
      }
   } 
   public void addFirst(int y)
   {
      int[] x = new int[head.length+1];
      for (int c = head.length; c > 0; c--)
      {
         x[c] = head[c-1];   
      }
      x[0] = y;
      head = x;   
   } 
   public String element(int x)
   {
      if (head == null)
         return "null";
      if (x >= head.length)
         return "null";  
      return (Integer.toString(head[x]));   
   }
   public void set(int x, int y)
   {
      if (head != null)
      {
         if (x < head.length)
         {
            head[x] = y;   
         }
      }   
   }
   public int indexOf(int x)
   {
      if (head != null)
      {
         for (int c = 0; c < head.length; c++)
         {
            if (head[c] == x)
               return c;
         }
      }
      return -1;
   } 
   public int size()
   {
      if (head == null)
         return -1;
      return head.length;
   }
   public boolean contains(int x)
   {
      for (int c = 0; c < head.length; c++)
      {
         if (head[c] == x)
            return true;
      }
      return false;
   }
   public void clear()
   {
      head = null;
   }
}