public class StringInsertDelete {
  public static void main(String [] args) {
    String s = "It was a bright cold day in April, " + 
               "and the clocks were striking thirteen.";
    int startThirteen = s.indexOf("thirteen");
    int endThirteen = startThirteen + "thirteen".length();
    s = s.substring(0, startThirteen) 
        + "twenty-five"
        + s.substring(endThirteen, s.length());
  }
}
