import java.util.Arrays;

public class MethodArray{
public static void func (int [] a){
int [] b = new int[a.length+1];
for(int i = 0; i<a.length; i++)
   b[i] = a[i];
b[b.length-1] = 4;
a = b;
}

public static int[] func2 (int [] a){
int [] b = new int[a.length+1];
for(int i = 0; i<a.length; i++)
   b[i] = a[i];
b[b.length-1] = 4;
return b;
}

public static void main(String [] args){
int [] a = {1, 2, 3};
func(a);
System.out.println(Arrays.toString(a));
a = func2(a);
System.out.println(Arrays.toString(a));
}
}
