public class WhatsPrinted01 {
public static void func(int A[]) {
for (int i=1; i<A.length; i++)
A[i]+=A[i-1];
}

public static void main(String args[]) {
int A[] = {10,20,30};
func(A);
System.out.println(A[2]);
}
}
