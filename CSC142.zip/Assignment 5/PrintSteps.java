public class PrintSteps
{
  public static void Step1()
  {
    System.out.println("-----");
    System.out.println("     |");
    System.out.println("     |");
  }
  public static void Step2()
  {
    System.out.println("      -----");
    System.out.println("           |");
    System.out.println("           |");

  }
  public static void main(String[] args)
   {
      Step1();
      Step2();
   }
}
