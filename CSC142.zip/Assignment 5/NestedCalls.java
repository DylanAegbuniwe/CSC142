public class NestedCalls 
{
  public static boolean mystery1(int a) 
  {
    if(a > 0 && mystery2(-a)) {
      return true;
    }
    return false;
  }

  public static boolean mystery2(int b) 
  {
    if(b + 2 > 0) {
      return false;
    }
    return true;
  }

  public static void main(String [] args) 
  {
    System.out.println("main");
    int x = 3;
    if(mystery1(x)) {
      System.out.println("mystery1 returns true");
    }
    System.out.println("mystery2 = " + mystery2(x));
  }
}
