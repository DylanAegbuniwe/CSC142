import java.util.*;
public class Method {

public static boolean evenCheck(int X){
    if(X % 2 == 0){
        return true;
    }
    else{
        return false;
    }
}

public static void Square(){
   int N;
   Scanner input = new Scanner (System.in);
   System.out.println("Enter a side for the square.");
   N = input.nextInt();
   for(int i = 1; i <= N; i++)
		{
			for(int j = 1; j <= N; j++)
			{
				System.out.print("*"); 
			}
			System.out.println(""); 
		}	
}
public static boolean primeCheck(int N){
    for(int i=2;i<N;i++){
        if(N % i == 0){
            return false;
        }
    }
    return true;
}

public static void main(String [] args){
    Scanner input = new Scanner(System.in);
    System.out.println("Enter X. If X is even, then it will display true. If not, then false.");
    int X = input.nextInt();
    System.out.println(evenCheck(X));
    System.out.println("Enter N. If N is prime, it will display true. If not, then false.");
    int N = input.nextInt();
    System.out.println(primeCheck(N));
    Square();
    }
}