public class PrintSquares
{
  public static void Square1()
  {
    System.out.println("****");
    System.out.println("*  *");
    System.out.println("*  *");
    System.out.println("****");
    System.out.println();
  }
  public static void Square2()
  {
    System.out.println("****");
    System.out.println("*  *");
    System.out.println("*  *");
    System.out.println("****");
  }
  public static void main(String[] args)
   {
      Square1();
      Square2();
   }
}

  
