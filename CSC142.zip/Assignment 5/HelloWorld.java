import java.util.Arrays;
public class HelloWorld
{
  public static void main(String [] args) 
  {
    int [] arr = {3, 7, 5};
    String arrStr = Arrays.toString(arr);
    System.out.println(arrStr);

    int max = Math.max(3, -5);
    System.out.println(max);

    String s = HelloWorld.getHello();
    System.out.println(s);
  }

  public static String getHello() {
    return "Hello, world!";
  }
}
