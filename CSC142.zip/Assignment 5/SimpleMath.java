public class SimpleMath
{
  public static int max(int a, int b, int c)
  {
    int temp = Math.max(a, b);
    return Math.max(temp, c);
  }

  public static double average(int a, int b, int c)
  {
    double sum = a + b + c;
    return sum / 3.0;
  }

  public static void main(String [] args) 
  {
    int x = 7;
    int y = 9;
    int z = 4;

    System.out.println(max(x,y,z));
    System.out.println(average(x,y,z));
  }
}
