public class Recursion
{
   public static void f(int x, int a, int b, int c)
   {
      if (x>0)
      {
         f(x-1, a, c, b);
         System.out.println(x+","+a+","+b+","+c);
         f(x-1,c, b, a);
      }
   }  
   public static void main(String[]args)
   {
      f(3,1,2,3);
   }
}