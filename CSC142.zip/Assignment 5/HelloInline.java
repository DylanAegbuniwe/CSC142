public class HelloInline
{
  // The order of method declarations does not matter!!
  public static String getHello() {
    return "Hello, world!";
  }

  // Program execution always begins with the first line of main().
  public static void main(String [] args) 
  {
    System.out.println(HelloInline.getHello());
    System.out.println(getHello());
    // Each time the command name is executed, the method is called.
    // We can call the method as many times as we like.
    System.out.println(getHello());
    System.out.println(getHello());
  }
}
