public class MethodWithArray { 
public static void mystery1 (double [ ] d) { 
  for(int i=1; i<d.length; i++){ 
       d[i] = d[i] - d[i-1]; 
  } 
} 

public static double [ ] mystery2 (double [ ] d) { 
  double [ ] ret = new double[d.length]; 
  for(int i=0;i<ret.length;i++){ 
       ret[i] = d[i]-1; 
       d[i] += 1; 
   } 
// POINT 1 
  return ret; 
}
 
public static void main (String [] args) { 
double [ ] d1 = {1.0,-1.0,3.0}; 
double [ ] d2 = {5.5,6.5,7.5}; 
mystery1(d1); 
double [ ] d3 = mystery2(d2); 
// POINT 2 
} 
}
