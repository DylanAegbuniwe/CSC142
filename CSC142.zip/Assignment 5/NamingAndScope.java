public class NamingAndScope
{
  public static void main(String [] args) 
  {
    int x = 3;
    x = x();
    System.out.println(x);
    x = x(x+1);
    System.out.println(x);
    for(int i=0; i<2; i++) {
      x = x(x+3);
      System.out.println(x);
    }
  }

  public static int x() 
  {
    int x = 5;
    return x + 7;
  }

  public static int x(int x)
  {
    return x + 1;
  }
}
