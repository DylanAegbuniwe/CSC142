// Java Program to Print Square Star Pattern
import java.util.Scanner;

public class SquareStar1 {
	private static Scanner sc;
	public static void main(String[] args) 
	{
		int N;
		sc = new Scanner(System.in);
		
		
		N = sc.nextInt();	
			
		for(int i = 1; i <= N; i++)
		{
			for(int j = 1; j <= N; j++)
			{
				System.out.print("*"); 
			}
			System.out.println(""); 
		}	
	}
}