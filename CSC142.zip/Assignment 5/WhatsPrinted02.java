public class WhatsPrinted02 {
public static int func(int A[], int B[]) {
 A = B;
 return A[1];
}

public static void main(String args[]) {
 int A[] = {10,20,30};
 int B[] = {40,50,60};

 int x = func(A, B);
 System.out.println(x + " " + A[1]);
 }
}
