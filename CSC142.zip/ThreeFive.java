import java.util.*;
public class ThreeFive
{
  public static void main(String[]args)
  {
   Scanner input = new Scanner(System.in);
   int row,column;
   System.out.println("Enter rows.");
   row = input.nextInt();
   System.out.println("Enter columns.");
   column = input.nextInt();
   for (int i = 1; i <= row; i++)
        {
 
            for (int j = i; j <= row * column; j += row)
            {
                System.out.print(j+" ");
            }
            System.out.println();
 
        }
 
    }
 }
