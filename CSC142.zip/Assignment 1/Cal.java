import java.util.*;
public class Cal
{
   public static void main(String[] args)
   {
      Scanner input = new Scanner(System.in);
      double sum = 0, num1=1, num2=0;
      int x=0;
      System.out.println("What is the number?");
      x = input.nextInt();
      
      for(int c = 1; c <= x; c++)
      {
         sum = sum + (num1/(x-num2));
         num1++;
         num2++;
      }
      System.out.println("The answer is "+sum+".");
   }
}