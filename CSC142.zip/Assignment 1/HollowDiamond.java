import java.util.*;
public class HollowDiamond
{
   public static void main(String[] args)
   {
      Scanner input = new Scanner(System.in);
      int x, y, z;
      int s = 1;
      System.out.println("How many rows are there?");
      int r = input.nextInt();
      int r2 = (2*r)-1;
      for (x = r; x >= 1; x--)
      {
         if (x == r)
         {
            for (y = 1; y <= r2; y++)
            {
               System.out.print("$");
            }
            System.out.println();
         }
            else
            {
               for (y = 1; y <= x; y++)
               {
                  System.out.print("$");
               }
               for (z = 1; z <= s; z++)
               {
                  System.out.print(" ");
               }
               for (y = 1; y <= x; y++)
               {
                  System.out.print("$");
               }
               System.out.println();
               s += 2;
            }         
      }
      s = s-4;
      for (x = 2; x <= r; x++)
      {
         if (x == r)
         {
            for (y = 1; y <= r2; y++)
            {
               System.out.print("$");
            }
            System.out.println();
         }
            else
            {
               for (z = 1; z <= x; z++)
               {
                  System.out.print("$");
               }
               for (y = 1; y <= s; y++)
               {
                  System.out.print(" ");
               }
               for (z = 1; z <= x; z++)
               {
                  System.out.print("$");
               }
               System.out.println();
               s -= 2;
            } 
      }   
   }
}