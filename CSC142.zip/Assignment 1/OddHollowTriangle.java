import java.util.*;
public class OddHollowTriangle
{
   public static void main(String[]args)
   {
      Scanner input = new Scanner(System.in);
      int r;
      System.out.println("How many rows are there?");
      r = input.nextInt();
      for(int x=1; x<=r; x++)
      {
         for(int y=5; y>=x; y--)
         {
            System.out.print(" ");
         }
         for(int z=1; z<x*2; z++)
         {
            if (z>1 && z<(x*2)-1)
            {
               System.out.print(" ");
            }
            else
            {
               System.out.print("$");
            }
         }
         System.out.println();
        } 
          for(int x=0; x>=r; x++)
      {
         for(int y=5; y>=x; y--)
         {
            System.out.print(" ");
         }
         for(int z=1; z<x*2; z++)
         {
            if (z>1 && z<(x*2)-1)
            {
               System.out.print(" ");
            }
            else
            {
               System.out.print("$");
            }
         }
         System.out.println(); 
      }
   }
}
