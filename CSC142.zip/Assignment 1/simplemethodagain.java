public class simplemethodagain
{
   public static void main(String[]args)
   {
      
      printGrid();//method calling
      
   }
   public static void printGrid(int row, int column)
    {
        for (int i = 1; i <= row; i++)
        {
 
            for (int j = i; j <= row * column; j += 4)
            {
                System.out.print(j+" ");
            }
            System.out.println();
 
        }
 
    }
   
}