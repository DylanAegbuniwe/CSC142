import java.util.*;
public class RightHollowTriangle
{
   public static void main(String[]args)
   {
      int rows;
      Scanner input = new Scanner(System.in);
      System.out.println("How many rows are there?");
      rows = input.nextInt();
      for (int R=rows; R>=1; R--)
      {
         for (int C=1; C<=R; C++)
         {
            System.out.print(" ");
         }
         System.out.println("$");
      }
   }
}