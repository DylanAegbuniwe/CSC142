public class StringCommands {
  public static void main(String [] args) {
    String s = "Call me Ishmael.";
    int len = s.length();
    int ishPos = s.indexOf("Ish");
    int jackPos = s.indexOf("Jack");
    String ishSub = s.substring(ishPos, len);
    char c = s.charAt(ishPos);
  }
}
