public class ArrayWithLoop1 {
  public static void main(String [] args) {
    int [] x = {-4, 9, 8, 2, -5, 7, 1};
    for(int i=1; i<x.length; i++) {
      x[i] += x[i-1]; // notice:  += instead of =
    }
  }
}
