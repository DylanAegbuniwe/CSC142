import java.util.*;

public class HollowDiamond{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   System.out.print("Enter row number: ");
   int n = kb.nextInt();
   for(int i = 0; i< 2*n-1; i++)
      System.out.print("$");
   System.out.println();
   for(int i = 0; i < n-1; i++){
      for(int j = 0; j<n-i-1; j++)
         System.out.print("$");
      for(int j = 0; j<2*i+1; j++)
         System.out.print(" ");
      for(int j = 0; j<n-i-1; j++)
         System.out.print("$");
      System.out.println();
      }
   for(int i = 0; i < n-2; i++){
      for(int j = 0; j<i+2; j++)
         System.out.print("$");
      for(int j = 0; j<2*(n-i)-5; j++)
         System.out.print(" ");
      for(int j = 0; j<i+2; j++)
         System.out.print("$");
      System.out.println();
      }
   for(int i = 0; i< 2*n-1; i++)
      System.out.print("$");
   System.out.println();
   System.out.println("Option two:");
   for(int i = 1; i< 2*n; i++)
      System.out.print("$");
   System.out.println();
   for(int i = 1; i < n; i++){
      for(int j = 1; j<=n-i; j++)
         System.out.print("$");
      for(int j = 1; j<2*i; j++)
         System.out.print(" ");
      for(int j = 1; j<=n-i; j++)
         System.out.print("$");
      System.out.println();
      }
   for(int i = 1; i < n-1; i++){
      for(int j = 1; j<=i+1; j++)
         System.out.print("$");
      for(int j = 1; j<2*(n-i)-2; j++)
         System.out.print(" ");
      for(int j = 1; j<=i+1; j++)
         System.out.print("$");
      System.out.println();
      }
   for(int i = 1; i< 2*n; i++)
      System.out.print("$");
   System.out.println();
   
   System.out.println("Option three.");
   for(int i = 1; i< 2*n; i++)
      System.out.print("$");
   System.out.println();
   int k = n-1;
   for(int i = 1; i<2*(n-1); i++){
      for(int j = 1; j<=k; j++)
         System.out.print("$");
      for(int j = 1; j<2*(n-k); j++)
         System.out.print(" ");
      for(int j = 1; j<=k; j++)
         System.out.print("$");
      System.out.println();
      if(i>n-2)k++;
      else k--;
   }
   for(int i = 1; i< 2*n; i++)
      System.out.print("$");
   System.out.println();
}
}
