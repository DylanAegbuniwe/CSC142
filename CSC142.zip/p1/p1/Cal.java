import java.util.*;

public class Cal{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   System.out.print("Enter a positive integer: ");
   int i = kb.nextInt();
   double total = 0;
   for(int j = 0; j<i; j++){
      total += (j+1.0)/(i-j); // why 1.0 not 1?
   }    
   System.out.println("t=0, i times, c=0, r: "+total);

   total = 0;
   for(int j = 1; j<=i; j++){
      total += j/(i-j+1.0); 
   }    
   System.out.println("t=0, i times, c=1, r: "+total);
   
   total = 1.0/i; // why 1.0 here?
   for(int j = 0; j<i-1; j++){
      total += (j+2.0)/(i-j-1); 
   }    
   System.out.println("t=1/i, (i-1) times, c=0, r: "+total);

   total = 1.0/i; 
   for(int j = 1; j<=i-1; j++){
      total += (j+1.0)/(i-j); 
   }    
   System.out.println("t=1/i, (i-1) times, c=1, r: "+total);
   
}
}