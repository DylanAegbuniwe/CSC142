import java.util.*;
public class ArrayWithLoop3 {
  public static void main(String [] args) {
    int [] x;
    int max,min,hold;
    Scanner input = new Scanner(System.in);
    System.out.println("Enter the first number.");
    max = input.nextInt();
    System.out.println("Enter the second number.");
    min = input.nextInt();
    if (min > max)
    {
      hold = max;
      max = min;
      min = hold;
    }
  }
}
