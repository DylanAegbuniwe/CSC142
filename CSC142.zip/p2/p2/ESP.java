import java.util.*;

public class ESP{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   Random rnd = new Random();
   System.out.println("Select a color 0-4:");
   System.out.println("Red 0, Green 1, Blue 2, Orange 3, Yellow 4");
   int total = 0;
   for(int i = 1; i<=10; i++){
      int ans = kb.nextInt();
      int seed = rnd.nextInt(5);
      System.out.println("Trial "+i+": computer("+seed+")");
      if(ans==seed){
         System.out.println("The player won!");
         total++;
      }
      else
         System.out.println("The player lost!");
   }
   System.out.println("Total win: "+total);
}
}