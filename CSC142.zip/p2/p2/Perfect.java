import java.util.*;

public class Perfect{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   System.out.print("Enter a positive integer: ");
   int N = kb.nextInt();
   int t = 0;
   for(int i = 1; i<N; i++) // do we need { } here?
      if(N%i==0) t+=i;
   if (N==t) System.out.println("Yes, it is a perfect number.");
   else System.out.println("No, it is not a perfect number.");
}
}