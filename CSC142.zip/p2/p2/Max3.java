import java.util.*;

public class Max3{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   int  max1, max2, max3, n1, n2, n3;
   System.out.print("Enter number 1: ");
   n1=kb.nextInt();
   System.out.print("Enter number 2: ");
   n2=kb.nextInt();
   System.out.print("Enter number 3: ");
   n3=kb.nextInt();
   if(n1>=n2){
      if(n3>=n1){
         max1=n3;
         max2=n1;
         max3=n2;
      }
      else if(n3>=n2){
         max1=n1;
         max2=n3;
         max3=n2;
      }
      else{
         max1=n1;
         max2=n2;
         max3=n3;
      }
   }//end if n1>n2
   else{ // n2>n1
      if(n3>=n2){
         max1=n3;
         max2=n2;
         max3=n1;
      }
      else if(n3>=n1){
         max1=n2;
         max2=n3;
         max3=n1;
      }
      else{
         max1=n2;
         max2=n1;
         max3=n3;
      }
   }// end if
   int n;
   for(int i = 4; i<=10; i++){
      System.out.print("Enter number "+i+": ");
      n=kb.nextInt();
      if(n>=max1){
         max3=max2;
         max2=max1;
         max1=n;
      }
      else{
         if(n>=max2){
            max3=max2;
            max2=n;
         }
         else if(n>=max3){
            max3=n;
         }
      }
   }
   System.out.println("Top 1: "+max1);
   System.out.println("Top 2: "+max3);
   System.out.println("Top 3: "+max3);
}
}   