import java.util.*;

public class Duration{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   int h1, h2, m1, m2;
   int t;
   boolean s = false;
   do{
   do{
      System.out.print("Enter the hour of start time: ");
      h1 = kb.nextInt();
   } while(h1<0||h1>23);
   do{
      System.out.print("Enter the minute of start time: ");
      m1 = kb.nextInt();
   } while(m1<0||m1>59);
   do{
      System.out.print("Enter the hour of end time: ");
      h2 = kb.nextInt();
   } while(h2<0||h2>23);
   do{
      System.out.print("Enter the minute of end time: ");
      m2 = kb.nextInt();
   } while(m2<0||m2>59);
   int t1 = h1*60+m1;
   int t2 = h2*60+m2;
   t = t2-t1;
   if(t<0) s = true;
   }while(s); 
   System.out.println("Duration is "+t/60+" hours and "+
      t%60 + " minutes.");
   if(t>60+15)
      System.out.println("Yes, there is enough time.");
   else
      System.out.println("No, not enough time for lunch.");
}
}