import java.util.*;

public class PrintGrid{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   System.out.print("Enter the value of rows: ");
   int rows = kb.nextInt();
   System.out.print("Enter the value of cols: ");
   int cols = kb.nextInt();
   for(int i = 0; i<rows; i++){
      int k = i+1;
      for(int j=0; j<cols-1; j++){
         System.out.print(k+",");
         k+=rows;
      }
      System.out.println(k);
   }
}
}
   
