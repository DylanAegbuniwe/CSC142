import java.util.*;

public class MinAvg{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   int  min, n;
   double t;
   System.out.print("Enter number 1: ");
   t=min=n=kb.nextInt();
   for(int i = 0; i<9; i++){
      System.out.print("Enter number "+(i+2)+": ");
      n=kb.nextInt(); // why not put this at the end of loop
      if(n<min)
         min = n;
      t+=n;
      // such as here?
   }
   System.out.println("Minimum is: "+min);
   System.out.println("Avg is:  "+t/10.0); // why 10.0, not 10?
   }
}