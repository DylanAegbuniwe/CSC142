import java.util.Scanner;
import java.io.*;
public class FiveOnly{
public static void main(String [] args) throws IOException
// do not forget to throw IOException
{
	Scanner keyboard = new Scanner(System.in);
	System.out.print("Enter the name of a file:  ");
	String filename = keyboard.nextLine();
	File inputFile = new File (filename);
	if(!inputFile.exists()){
		System.out.println("The file is not found.");
		System.exit(0);
	}
	Scanner input = new Scanner(inputFile);
   for(int i = 0; i<5 & input.hasNext(); i++){
	   String content = input.nextLine();
	   System.out.println(content);
	}
	input.close();
   // don't forget to close
}
}

