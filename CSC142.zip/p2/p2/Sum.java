import java.util.*;

public class Sum{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   int n;
   do{
      System.out.print("Enter an integer: ");
      n = kb.nextInt();
   }while(n<=0); // why =?
   
   // n = kb.nextInt(); while(n<=0) n=kb.nextInt();
   int t = 0;
   while(n>0){ // why no =?
      t += n%10;
      n /= 10; 
   }
   System.out.println("Total is: "+t);
   }
}