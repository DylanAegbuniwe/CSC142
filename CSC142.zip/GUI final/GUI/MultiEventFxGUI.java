import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.control.TextField;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;


public class MultiEventFxGUI extends Application
{
   RadioButton btnFlower;
   RadioButton btnSunset;
   Image imgFlower;
   Image imgSunset;      
   ImageView view;
   
   public static void main(String args[])
   {  
      launch();
   }
   public void start(Stage primaryStage)
   {
      //image imgFlower = new Image("file:C:\\...");
      imgFlower = new Image("file:flower.jpeg");
      imgSunset = new Image("file:sunset.jpeg");
      
      view = new ImageView(imgFlower);
      
      view.setFitWidth(400);
//      view.setPreserveRatio(true);
      
      HBox boxImage = new HBox(view);
      boxImage.setAlignment(Pos.CENTER);
      
      btnFlower = new RadioButton("Flower");
      btnFlower.setOnAction(new btnControlHandler());
      btnSunset = new RadioButton("Sunset");
      btnSunset.setOnAction(new btnControlHandler());
      
      btnFlower.setSelected(true);
      
      ToggleGroup radio = new ToggleGroup();
      btnFlower.setToggleGroup(radio);
      btnSunset.setToggleGroup(radio);
      
      HBox boxBtn = new HBox(10, btnFlower, btnSunset);
      boxBtn.setPadding(new Insets(30));
      
      VBox boxMain = new VBox(10, boxImage, boxBtn);
      
      Scene scene = new Scene (boxMain);
           
      primaryStage.setScene(scene);
      
      primaryStage.setTitle("Image Application");
      primaryStage.show();
   }
   
   class btnControlHandler implements EventHandler<ActionEvent>{
      public void handle(ActionEvent e)
      {
         if(btnFlower.isSelected()){
            System.out.println("BTN flower is selected");
            view.setImage(imgFlower);
         }
         if(btnSunset.isSelected()){
            System.out.println("BTN Sunset is selected");
            view.setImage(imgSunset);
         }
      }
   }
}