import javafx.application.Application;
import javafx.stage.Stage;

public class MyFirstFxGUI extends Application
{
   public static void main(String args[])
   {  
      launch();
   }
   public void start(Stage primaryStage)
   {
      primaryStage.setTitle("My First GUI Application");
      primaryStage.show();
   }
}