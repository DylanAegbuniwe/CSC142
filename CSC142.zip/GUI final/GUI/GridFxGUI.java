import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;

public class GridFxGUI extends Application
{
   public static void main(String args[])
   {  
      launch();
   }
   public void start(Stage primaryStage)
   {
      int size = 17;
      int col = 5;
      Label [] lbl = new Label[size];
      for(int i = 0; i < size; i++){
         lbl[i] = new Label("message"+i);
      }
      
      GridPane gridLabel = new GridPane();
      
      for(int i = 0; i < size; i++){
         gridLabel.add(lbl[i], i%col, i/col); 
      }
      
      Button [] btn = new Button[size];
      for(int i = 0; i < size; i++){
         btn[i] = new Button("button "+i);
      }
      
      GridPane gridButton = new GridPane();
      
      for(int i = 0; i < size; i++){
         gridButton.add(btn[i], i%col, i/col); 
      }
      gridLabel.setAlignment(Pos.TOP_LEFT);
      gridButton.setAlignment(Pos.BOTTOM_LEFT);
      
      VBox box = new VBox (10, gridLabel, gridButton);
      
      Scene scene = new Scene (box, 600, 300);
      
      box.setAlignment(Pos.CENTER);
      
      
      primaryStage.setScene(scene);
      primaryStage.setTitle("Layout Application");
      primaryStage.show();
   }
}