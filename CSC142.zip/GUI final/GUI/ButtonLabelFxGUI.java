import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.geometry.Pos;

public class ButtonLabelFxGUI extends Application
{
   public static void main(String args[])
   {  
      launch();
   }
   public void start(Stage primaryStage)
   {
      Label lblMessage = new Label("message");
      Button btnControl = new Button("Press it");
      
      HBox box = new HBox (10, lblMessage, btnControl);
      // HBox box = new HBox(lblMessage); 
      // VBox box = new VBox (10, lblMessage, btnControl, ...);
      Scene scene = new Scene (box, 300, 100);
      
      box.setAlignment(Pos.CENTER);
      
      primaryStage.setScene(scene);
      primaryStage.setTitle("Output Application");
      primaryStage.show();
   }
}