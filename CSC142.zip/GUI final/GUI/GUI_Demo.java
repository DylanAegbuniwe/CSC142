import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 Simple demonstration of putting buttons in a JFrame window.
*/
public class GUI_Demo extends JFrame implements ActionListener
{
    int n1, n2;
    int op;
    public static final int WIDTH  = 400;
    public static final int HEIGHT = 200;
    private JButton buttons[];
    private JLabel label;
    private String digits[] = 
    {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
    private String operator[] = {"+", "-", "*", "/", "="};
    public GUI_Demo( )
    {
        super (" Game demo ");
        setSize(WIDTH, HEIGHT);

        JPanel buttonPanel = new JPanel();
        JPanel textPanel = new JPanel();
        
        label = new JLabel();
        textPanel.setLayout(new FlowLayout());
        textPanel.add(label);
        
        
        buttonPanel.setLayout(new GridLayout(3, 5));
         
        buttons = new JButton[digits.length+operator.length];
        for(int i=0; i<digits.length; i++){
         buttons[i] = new JButton(digits[i]);
         buttons[i].addActionListener(this);
         buttonPanel.add(buttons[i]);
        } 
        for(int i=0; i<operator.length; i++){
         buttons[i+digits.length] = new JButton(operator[i]);
         buttons[i+digits.length].addActionListener(this);
         buttonPanel.add(buttons[i+digits.length]);
        } 
        
        BorderLayout layout = new BorderLayout();
        Container  pane = getContentPane();
        pane.setLayout(layout);
        pane.add(textPanel, BorderLayout.NORTH);
        pane.add(buttonPanel, BorderLayout.SOUTH);
        
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e)
    {
        String actionCommand = e.getActionCommand( );
        Container contentPane = getContentPane( );
        for(int i = 0; i<digits.length; i++){
        if (actionCommand.equals(digits[i]))
           label.setText(label.getText()+digits[i]);
        }
        for(int i = 0; i<operator.length-1; i++){
        if (actionCommand.equals(operator[i])){
           n1 = Integer.parseInt(label.getText());
           label.setText("");
           op = i;
           }
        }
        if (actionCommand.equals("=")){
           n2 = Integer.parseInt(label.getText());
           label.setText("");
           int result=0;
           switch (op)
           {
            case 0:  result = n1 + n2;
                     break;
            case 1:  result = n1 - n2;
                     break;
            case 2:  result = n1 * n2;
                     break;
            case 3:  result = n1 / n2;
                     break;
            }
            label.setText(""+result);
        }        
    }
    public static void main(String [] args){
      GUI_Demo app = new GUI_Demo();
      app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}


