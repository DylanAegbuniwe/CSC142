import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.control.TextField;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;

public class SingleEventFxGUI extends Application
{
   TextField txtInput;
   Label lblResult;
   
   public static void main(String args[])
   {  
      launch();
   }
   public void start(Stage primaryStage)
   {
      Label lblMessage = new Label("Enter a distance in kilometers:");
      txtInput = new TextField(); 
      Button btnControl = new Button("Convert");
 
      btnControl.setOnAction(new btnControlHandler());
      
      lblResult = new Label("Result:");
      
      HBox topBox = new HBox(10, lblMessage, txtInput);
      
      VBox box = new VBox(10, topBox, btnControl, lblResult);
      
      box.setAlignment(Pos.CENTER);
      
      box.setPadding(new Insets(10));
      
      Scene scene = new Scene (box);
      
      box.setAlignment(Pos.CENTER);
      
      primaryStage.setScene(scene);
      
      primaryStage.setTitle("Input/Output Application");
      primaryStage.show();
   }
   
   class btnControlHandler implements EventHandler<ActionEvent>{
      public void handle(ActionEvent e)
      {
         double k = Double.parseDouble(txtInput.getText());
         double m = k * 0.6214;
         lblResult.setText(lblResult.getText()+" "+(int)(m*100)/100.00);
      }
   }
}