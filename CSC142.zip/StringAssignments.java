public class StringAssignments {
  public static void main(String [] args) {
    String s;
    String t = null;
    String u = "you";
    String v = new String("me");
    String w = u + v;
  }
}
