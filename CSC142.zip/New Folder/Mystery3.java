public class Mystery3 {
  private String s = "ba";
  int n = 3;
  public String getStr
               (int n){
    for(int i=0;i<n;i++){
      s = s + n;
    }
    return s;
  } // this.n and n; obj.m()
}
