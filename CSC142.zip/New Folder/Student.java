public class Student {
private String name;
private int grade[];
// No more any other attribute.
public Student(String n, int[] g){
name = n;
grade = new int [g.length];
for(int i = 0; i<g.length; i++)
   grade[i] = g[i];
}
public double get_average(){
double r = 0;
for(int i = 0; i<grade.length; i++)
r+= grade[i];
return r/grade.length;
}
public String get_name(){
return name;
}
public String toString(){
double r = get_average();
if(r>=90) return "A";
else if (r>=80) return "B";
else if (r>=65) return "C";
else if (r>=60) return "D";
else if (r>=0) return "F";
else return "N/A";
}
public int compareTo(Student right){
double l = get_average();
double r = right.get_average();
if (l==r) return 0;
else if (l<r) return -1;
else return 1;
}
}