public class CIS142 {
public static void main(String [] args){
int [] g1 = {70,80,90};
int [] g2 = {40,60,65,90};
Student a = new Student("Jack", g1);
Student b = new Student("Jill", g2);
if(a.compareTo(b)>=0) System.out.println(a.get_name()+","+a);
if (a.compareTo(b)<=0) System.out.println(b.get_name()+","+b);
}
}