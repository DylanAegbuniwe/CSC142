public class problem2{
public static void main(String[] args)
{
Mystery3 m1 = 
   new Mystery3();
String str1 = 
   m1.getStr(1);

Mystery3 m2 = 
   new Mystery3();
String str2 = 
   m2.getStr(2);
   System.out.println(m1);
   System.out.println(str1);
   System.out.println(m2);
   System.out.println(str2); 
}
}