public class problem1{
public static void main(String []args)
{
Mystery2 m1 = 
   new Mystery2();
int x =
      m1.getVal();
Mystery2 m2 = 
   new Mystery2();
x = m2.getVal();
x = m2.getVal();
}
}
