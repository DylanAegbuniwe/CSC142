public class Mystery2 { 
  private int a = 0, b = 1;
  public int getVal() 
  {
    a = a + b;
    return a;
  }
}
