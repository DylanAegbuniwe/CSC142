public class StringEquals {
  public static void main(String [] args) {
String s = "hibbity hibbity" + 
" hibbity hibbity";
int i=0;
int count = 0;
while(i<s.length()-3) {
	if(s.substring(i,i+3).equals("bit")) {
		count++;
	}
	i++;
}
  }
}
