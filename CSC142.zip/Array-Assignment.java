public class Array-Assignment {
  public static void main(String [] args) {
    int [] x = new int[3];
    int [] y = {3, 5, 9, 2};
    x[2] = y[3];
    x[0]++;
    y[1] += y[2] * y[0];
    int [] z = x;
    x = y;
  }
}
