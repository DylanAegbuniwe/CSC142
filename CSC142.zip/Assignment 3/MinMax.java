import java.util.*;
public class MinMax {
  public static void main(String [] args) {
    int [] x = new int [25];
    int max = x[0];
    int min = x[0];
    Scanner input = new Scanner(System.in);
    for(int i = 0; i<x.length; i++)
    {
      System.out.print("Enter number "+i+": ");
      x[i] = input.nextInt();
      if (i == 1 && x[i] > x[0])
      {
         min = max;
         max = x[i];
      }
      else if (i == 1 && x[i] < x[0])
      {
         min = x[i];
      }
      if (x[i] > max)
      {
         min = max;
         max = x[i];
      }
      if (x[i] < min)
      {
         min = x[i];
      }
    }
    System.out.println("The max is "+max);
    System.out.println("The minimum is "+min);
  }
}
