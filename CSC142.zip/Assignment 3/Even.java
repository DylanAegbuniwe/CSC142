import java.util.*;
public class Even 
{
  public static void main(String [] args) 
  {
   Scanner input = new Scanner(System.in);
   int [] intArr = new int[25];
   for(int i=0; i<intArr.length; i++) 
   {
      System.out.print("Enter number "+i+": ");
      intArr[i] = input.nextInt();
   }
   int countEven = 0;
   for(int i=0; i<intArr.length; i++) 
   {
      if(intArr[i] % 2 == 0) 
      {
         countEven++;
      }
   }
   if(countEven % 2 == 0) 
   { 
      System.out.println("true");
   } 
   else 
   {
      System.out.println("false");
   }
  }
}