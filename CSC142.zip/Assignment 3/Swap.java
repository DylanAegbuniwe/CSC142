import java.util.*;
public class Swap {
  public static void main(String [] args) 
  {
   Scanner input = new Scanner(System.in);
   int [] intArr = new int[25];
   for(int i=0; i<intArr.length; i++)
   {
      System.out.print("Enter number "+i+": ");
      intArr[i] = input.nextInt();
   }
   int max = intArr[0];
   int maxPos = 0; 
   for(int i=1; i<intArr.length; i++) 
   {
      if(intArr[i] > max) 
      {
         max = intArr[i];
         maxPos = i;
      }
   }
   int min = intArr[0];
   int minPos = 0;
   for(int i=1; i<intArr.length; i++) 
   {
      if(intArr[i] < min) 
      {
         min = intArr[i];
         minPos = i;
      }
   }
   intArr[minPos] = max;
   intArr[maxPos] = min;
   System.out.println(Arrays.toString(intArr));
   }
}