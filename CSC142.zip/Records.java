public class Records extends Student
 {
   private int [] test = null;
   private int [] quiz = null;
   private int [] assignment = null;
   
   public Records (String name, int tn, int qn, int an, int tw, int qw, int aw){
      super(name, tw, qw, aw);
      test = new int [tn];
      quiz = new int [qn];
      assignment = new int [an];
   }
   public void set_test(int[] x)
      {
         for (int c = 0; c < x.length; c++)
         {  
            test[c] = x[c];
         }
      }
   public void set_quiz(int[] x)
   {
      for (int c = 0; c < x.length; c++)
      {  
         quiz[c] = x[c];
      }  
   }
      
   public void set_assignment(int[] x)
   {
      for (int c = 0; c < x.length; c++)
      {  
         assignment[c] = x[c];
      }
   }

   public double get_test()
   {
      double avg = 0;
      for(int c = 0; c < test.length; c++)
      {
         avg += test[c];
      }
      avg = (avg/test.length);
      return avg;
   }
    
   public double get_quiz()
   {
      double avg = 0;
      for(int c = 0; c < quiz.length; c++)
      {
         avg += quiz[c];
      }
      avg = (avg/quiz.length);
      return avg;
   }
   
    public double get_assignment()
   {
      double avg = 0;
      for(int c = 0; c < assignment.length; c++)
      {
         avg += assignment[c];
      }
      avg = (avg/assignment.length);
      return avg;
   }
   public void grading()
   {
      double[] score = new double[3];
      int y = 0;
      if ((test.length >= 1) && (test != null)) 
         score[0] = get_test();    
      else
         score[0] = 0;  
      if ((quiz.length >= 1) && (quiz != null)) 
         score[1] = get_quiz();
      else
         score[1] = 0;           
      if ((assignment.length >= 1) && (assignment != null))
         score[2] = get_assignment();
      else
         score[2] = 0;   
      letter_grading(score);
   }
   public String toString()
   {
      String str = "";
      str += get_name();
      if ((test.length >= 1) && (test != null))
      {
         String t = "[" + test[0];
         for (int c = 1; c < test.length; c++)
            t += (", "+test[c]);
         t += "]";   
         str += ("\nTest score:"+t);
      }
      if ((quiz.length >= 1) && (quiz != null))
      {
         String q = "[" + quiz[0];
         for (int c = 1; c < quiz.length; c++)
            q += (", "+quiz[c]);
         q += "]";
         str += ("\nQuiz score:"+q);
      }   
      if ((assignment.length >= 1) && (assignment != null))
      {
         String a = "[" + assignment[0];
         for (int c = 1; c < assignment.length; c++)
            a += (", "+assignment[c]);
         a += "]";
         str += ("\nAssignment score:"+a);
      }   
      str += ("\nGPA:"+get_gpa());
      return str;            
   }
}   
   