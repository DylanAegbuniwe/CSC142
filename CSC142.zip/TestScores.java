public class TestScores
{
   private double score1;
   private double score2;
   private double score3;
   private double avg;
   public TestScores(int[] x)
   {
      score1 = x[0];
      score2 = x[1];
      score3 = x[2];
      avg = ((score1+score2+score3)/3);
   }
   public TestScores(int x, int y, int z)
   {
      score1 = x;
      score2 = y;
      score3 = z;
      avg = ((score1+score2+score3)/3);
   }
   public double getAvg()
   {
      return avg;
   }
   public String toString()
   {
      return Double.toString((score1+score2+score3)/3);
   }
   public int compareTo(TestScores x)
   {
      if (avg > x.getAvg())
      {
         return 1;
      }
      if (avg < x.getAvg())
      {
         return -1;
      }
      return 0;      
   }
}