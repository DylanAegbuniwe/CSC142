import java.util.*;
public class Number_1
{
   public static void main(String[] args)
   {
      System.out.println(f1(4096));
      System.out.println(f2(3,3));
      System.out.println(f3(6, 1999));
      f4(5);
      System.out.println();
      System.out.println(f5(5));
      f6(1,5);
      
   }
   
   public static int f1(int N)
   {
      if (N <= 1)  
         return 1;
      else 
      {
         int result = N + f1(N/2);
         return result; 
      }
   }
   
   public static double f2(double N, double i) 
   {
      if(N==1)
         return 1/i;
      else
      { 
         double x = N/((i+1)-N);
         double result = x + f2(N-1, i);
         return result;   
      }
   }
   
   public static double f3(double N, int y)
   {
      double sum = 0;
      if(N>=10)
         return y;
      else
      {
         y++;
         sum = sum + f3((N+(N*.014)),y);
         return sum;        
      }
   }
   
   public static void f4(int N)
   {
      if (N == 1)
         System.out.print("1 ");
      else
      {
         f4(N-1);
         System.out.print(N + " ");
      }
   }
   
   public static String f5(int N)
   {
      String str = "";
      if (N == 1)
         return "1";
      else
      {
         String s = Integer.toString(N);
         s += " ";
         str += s + (f5(N-1));
         return str;
      }
   }
   public static void f6(int start, int end)
   {
       if ( start > end  && end > 1) 
       {
           System.out.print((end - 1)+ " ");
           f6(start, end - 1);    
       } 
       if (start <= end) {
           System.out.print(start + " ");
           f6(start + 1, end);
       }
   }      


}   