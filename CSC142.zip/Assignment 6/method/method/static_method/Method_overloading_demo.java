import java.util.*;
import java.io.*;

public class Method_overloading_demo
{
public static int square(int x){
return x * x;
}

public static int square(double x){
return (int)(x * x); //type casting, 56.25 = 56!
}

public static double area(int x) {
return Math.PI * x * x;
}

public static int area (int x, int y){
return x * y; // return integer
}

public static void main(String [] args) 
{
   int i_result = square(7); // calls int version
   double d_result = square(7.5); // calls double version
   
   System.out.println("The square of integer 7 is "+i_result);
   System.out.println("The square of double 7.5 is "+d_result);     

   double circle = area(7); // calls with one argument
   double rectangle = area(5, 7); // calls with two arguments, casting
   
   System.out.println("The area of a circle with radius 7 is "+circle);
   System.out.println("The area of a rectangle is "+rectangle);     
}
}
 