public class Hanoi {
public static void f(int x, int a, int b, int c){
if (x>0){
   f(x-1, a, c, b);
   System.out.println(x+","+a+","+b);
   f(x-1,c, b, a);
}
}


public  static int h(int x, int y){
System.out.println(x+","+y);
if (x==0) return (y+1);
else if (y==0) return h(x-1, 1);
else return h(x-1, h(x,y-1));
}


public static int g(int [ ] n, int first, int last, int v){
int middle;
if (first > last) return -1;
middle = (first + last)/2;
System.out.println("first ("+first+"), last ("+last+"), middle ("+middle+")"); 
if(n[middle] == v) return middle;
       else if ( n[middle] < v) return g(n, middle+1, last, v);
       else return g(n, first, middle-1, v);
}


public static void main(String [] args){
f(3, 1, 2, 3);
System.out.println(h(2,2));
int [ ] n = {101, 142, 147, 189, 199, 207, 222, 234, 289, 296, 310, 319, 388, 394, 417, 429};
System.out.println("g(n,0,14,417)="+g(n, 0, 14, 417));
System.out.println("g(n,0,13,417)="+g(n, 0, 13, 417));

}
}