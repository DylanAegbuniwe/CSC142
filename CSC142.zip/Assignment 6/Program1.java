import java.util.*;
public class Program1
{
   public static void main(String []args)
   {
      System.out.println(f1(4096));
      System.out.println(f2(3,3));
      System.out.println(f3(6,1999));
      f4(6);
      System.out.println(f5(6));
      f6(1,6);
   }
   
   public static int f1(int N)
   {
      if (N <= 1)
      {
         return 1;
      }
      else
      {
         int result = N + f1(N/2);
         return result;
      }
   }
   public static double f2(double N, double i)
   {
      if(N==1){
         return 1/i;
      }
      else
      {
         double a = N/((i+1)-N);
         double b = a + f2(N-1, i);
         return b;
      }
   
   }
   
   public static double f3(double m, int year)
   {
      double sum = 0;
      if (m >= 10){
         return year;
      }
      else
      {
         year++;
         sum = sum + f3((m+(m*.014)),year);
         return sum;
      }
   
   }
   
   public static void f4(int N)
   {
      if (N == 1)
         System.out.print("1 ");
      else
      {
         f4(N-1);
         System.out.print(N + " ");
      }
   }
   public static String f5(int a)
   {
      String str = "";
      if (a==1){
         return "1";
      }
      else {
         String b = Integer.toString(a);
         b += " ";
         str += b + (f5(a-1));
         return str;
      }
   }
   
   public static void f6(int x, int y)
   {
       if ( x > y  && y > 1) 
       {
           System.out.print((y - 1)+ " ");
           f6(x, y - 1);    
       } 
       if (x <= y) {
           System.out.print(x + " ");
           f6(x + 1, y);
       }
   }
   
 }