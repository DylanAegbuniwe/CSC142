import javax.swing.*;
public class Duration
{
   public static void main(String[] args)
   {
      int startHour = 0, startMin = 0, startTotalMin = 0, endHour = 0, endMin = 0, endTotalMin = 0, finalDif = 0; 
      String input, hour, min;
      do
      {
         input = JOptionPane.showInputDialog("What is the starting time? Please enter in HH:MM");
         hour = input.substring(0,2);
         startHour = Integer.parseInt(hour);
         min = input.substring(3,5);
         startMin = Integer.parseInt(min);
      }
      while(!(startHour < 24 && startMin < 60));
      
       do
      {
         input = JOptionPane.showInputDialog("What is the meeting time? Please enter in HH:MM.");
         hour = input.substring(0,2);
         endHour = Integer.parseInt(hour);
         min = input.substring(3,5);
         endMin = Integer.parseInt(min);
      }
      while(!(endHour < 24 && endMin < 60));
      
      startTotalMin = (startHour * 60) + startMin;
      endTotalMin = (endHour * 60) + endMin;
      
      if(startTotalMin >= endTotalMin)
      {
         JOptionPane.showMessageDialog(null, "Your end time is before your start time.\nPlease enter it again.");
         System.exit(0);
      }
     
      finalDif = endTotalMin - startTotalMin;
      
      if(finalDif >= 75)
      {
         JOptionPane.showMessageDialog(null, "You will have enough time to take an hour and fifteen minute lunch break.");
      }
      else
      {
         JOptionPane.showMessageDialog(null, "You won't have enough time to take an hour and fifteen minute lunch break.");        
      }
   }
}   
    
     
         
         