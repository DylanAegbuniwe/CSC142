import java.util.*;
public class MinAvg 
{    
   public static void main(String[] args)
   {       
      int i,n=0,s=0;
	   double avg, min;
      Scanner input = new Scanner(System.in);
      System.out.println("Input the 10 numbers.");
      n = input.nextInt();
      min = n;          

		for (i=1;i<10;i++)
		{
		    n = input.nextInt();        
          if(n < min)
          {
            min = n;
          }
		    
  		s +=n;
	   }
	   avg=s/10;
	   System.out.println("The minimum is " +min+"\nThe Average is " +avg);
   }
}
