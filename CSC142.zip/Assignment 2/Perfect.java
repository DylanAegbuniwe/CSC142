import java.util.Scanner;
public class Perfect
{
    public static void main(String[] args) 
    {
        int num, sum = 0;
        Scanner input = new Scanner(System.in);
        System.out.println("What is the number?");
        num = input.nextInt();
        for(int i = 1; i < num; i++)
        {
            if(num % i == 0)
            {
                sum = sum + i;
            }
        }
        if(sum == num)
        {
            System.out.println("The number is perfect.");
        }
        else
        {
            System.out.println("The number isn't perfect.");
        }    
    }
}