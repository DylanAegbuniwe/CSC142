import java.util.*;
public class Sum
{
   public static void main(String[]args)
   {
      int num, x, sum=0;
      Scanner input = new Scanner(System.in);
      System.out.println("What is the number?");
      num = input.nextInt();
      while(num <= 0)
      {
         System.out.println("Please input a positive number.");
         num = input.nextInt();
      }
      while(num > 0)
        {
            x = num % 10;
            sum = sum + x;
            num = num / 10;
        }
      System.out.println("The sum of digits is "+sum);
   }
}
      
         