import java.util.*;
import javax.swing.*;
public class ESP
{
   public static void main(String[] args)
   {
      int max = 4, min = 0, computer, score=0, uInput=0;
      String color = "Invalid Input";
      String input;
      Random rand = new Random();
      JOptionPane.showMessageDialog(null, "The computer will randomly choose a color.\nYour goal is to correctly guess the selected color.");;
      
      for(int rounds=1; rounds<=9; rounds++)
      {
         computer = rand.nextInt((max - min) + 1) + min;         
         
         switch(computer)
         {
            case 0: color = "Red"; break; 
            case 1: color = "Green"; break;
            case 2: color = "Blue"; break;
            case 3: color = "Orange"; break;
            case 4: color = "Yellow"; break;
         }
         
         input = JOptionPane.showInputDialog("Type \"Red\",\"Green\",\"Blue\",\"Orange\", or \"Yellow\".");
         
          switch(input)
         {
            case "Red": uInput = 0;
            case "red": uInput = 0; break;
            case "Green": uInput = 1; 
            case "green": uInput = 1; break;
            case "Blue": uInput = 2;
            case "blue": uInput = 2; break;
            case "Orange": uInput = 3; 
            case "orange": uInput = 3; break;
            case "Yellow": uInput = 4; 
            case "yellow": uInput = 4; break;
            default: input = "Invalid Input"; break;             
         }
         if(computer == uInput)
         {
            score = score +1;
            JOptionPane.showMessageDialog(null, "The color was: "+color+"\nYou guessed: "+input+"\nYour score is: "+score);
         }
         else
         {
            JOptionPane.showMessageDialog(null, "The color was: "+color+"\nYou guessed: "+input+"\nYour score is: "+score);
         }
      }
      JOptionPane.showMessageDialog(null, "The game has ended!\nYour score was: "+score);
   }
}


          
            
      
