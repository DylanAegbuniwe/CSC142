import java.util.*;
public class Max3
{
   public static void main(String[] args)
    { 
      int large1=0;
      int large2=0;
      int large3=0; 
      int num;
      Scanner input=new Scanner(System.in);
      System.out.println("Enter ten numbers.");
      num=input.nextInt();
      large1 = num;
      for(int i=1;i<3;i++)
        {
          num=input.nextInt();
          if (num > large1) 
          {
            large3 = large2;
            large2 = large1;
            large1 = num;
          } 
          else if (num < large1 && i < 2) 
          {
            large3 = large2;
            large2 = num;
            if (num < 0 && num < large1)
            {
               large2 = num;
            }
          } 
          else if (num < large2 && i < 3) 
          {
            large3 = num;
          }
       } 
      for(int j=1;j<=7;j++)
        {
          num=input.nextInt();
          if (num > large1) 
          {
            large3 = large2;
            large2 = large1;
            large1 = num;
          } 
          else if (num >= large2) 
          {
            large3 = large2;
            large2 = num;
          } 
          else if (num > large3)
          {
            large3 = num;
          }
       }
       System.out.print("The largest three numbers are "+large1);
       System.out.print(" "+large2);
       System.out.print(" and "+large3);
    }
}