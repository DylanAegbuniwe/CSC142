import java.util.*;
import java.io.*;
public class FiveOnly {
	
	public static void main(String[] args) throws IOException
	{ 
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a file name: ");
		String fileName = input.nextLine();
		File file = new File(fileName + ".txt");
		if(!file.exists())
      {
			System.out.println("The file " + fileName + ".txt does not exist.");
			System.exit(0);
		}
		Scanner inputFile = new Scanner(file);
		String line;
		int counter = 0;
		while(inputFile.hasNext())
      {
			line = inputFile.nextLine();
			if(counter < 5)
				System.out.println(line);
			counter += 1;
		}
		inputFile.close();
	}
}