import java.util.*;
public class TotalLength 
{
   public static void main(String [] args) 
   {
      Scanner keyboard = new Scanner(System.in);
      int totalLength = 0;
      for(int i=1; i<=10; i++) 
      {
         System.out.println("Enter string # "+i);
         String str = keyboard.next();
         totalLength = totalLength + str.length();
      }
      System.out.println("The total length is " + totalLength);
  }
}
