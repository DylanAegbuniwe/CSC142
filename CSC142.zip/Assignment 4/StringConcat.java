import java.util.*;
public class StringConcat
{
   public static void main(String args[])
   {
      Scanner keyboard = new Scanner(System.in);
      String inputStr, sumStr="";
      System.out.println("Enter a string. To end the string, enter 'stop.'");
      inputStr = keyboard.nextLine();
      if (!inputStr.equals("stop")){
         sumStr+= inputStr;
         inputStr = keyboard.nextLine();
         while (!inputStr.equals("stop")) {
            sumStr+=" not ";
            sumStr+=inputStr;
            inputStr = keyboard.nextLine();
         }
      }
 System.out.println(sumStr);
   }
}
