import java.util.*;
public class Reverse
{
   public static void main(String args[])
   {
      Scanner keyboard = new Scanner(System.in);
      String inputStr, reverseStr="";
      System.out.println("Input a string.");
      inputStr = keyboard.nextLine();
      int i;
      for(i=0; i< inputStr.length(); i++)
      {
         reverseStr += inputStr.charAt(inputStr.length()-i-1);
      }
      System.out.println(reverseStr); 
  }
}
