import java.util.Scanner;
public class Counting 
{
   public static void main(String [] args) 
   {
      Scanner keyboard = new Scanner(System.in);
      System.out.println("Input a string.");
      String str = keyboard.nextLine();
      int numS = 0;
      for(int i=0; i<str.length(); i++) 
      {
         char c = str.charAt(i);
         if(c == 's' || c == 'S') 
         {
            numS++;
         }
      }
      System.out.println(numS + " s's and S's in your String");
   }
}
 