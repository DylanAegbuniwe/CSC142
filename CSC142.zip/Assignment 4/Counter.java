import java.util.*;
public class Counter
{
   public static void main(String[] args) 
   {
		String text;
		char character;
		
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter a string: ");
		text = keyboard.nextLine();
		System.out.println("Enter a character: ");
		character = keyboard.nextLine().charAt(0);
		int count = 0;
		for(int i = 0; i < text.length(); i++)
      {
			if(text.charAt(i) == character)
         {
				count += 1;
			}
		}
		System.out.println("The character appears " + count + " times.");
	}
}