import javax.swing.*;
import java.util.*;
public class SlotM
{
   public static void main(String args[])
   {
      double userStringInput;
      double userAmountEntered;
      Random random = new Random();
      Scanner keyboard = new Scanner(System.in);
      int wordIndex;
      String word = "";
      String word1 = "";
      String word2 = "";
      String word3 = "";
      String playAgain = "y";
      double totalUserAmountEntered = 0;
      
      while (playAgain == "y" || playAgain == "Y" || playAgain == "yes" || playAgain == "Yes")
      {
         System.out.println("Insert money.");
         userAmountEntered = keyboard.nextDouble();
         totalUserAmountEntered += userAmountEntered;
      
         for (int wordCount = 1; wordCount <= 3; wordCount++){
            wordIndex = random.nextInt(6);
      
            if (wordIndex == 0){
               word = "Cherries";
            } else if (wordIndex == 1) {
               word = "Oranges";
            } else if (wordIndex == 2) {
               word = "Plums";
            } else if (wordIndex == 3) {
               word = "Bells";
            } else if (wordIndex == 4) {
               word = "Melons";
            } else if (wordIndex == 5) {
               word = "Bars";
            }
            
            if (wordCount == 1){
               word1 = word;
            } else if (wordCount == 2){
               word2 = word;
            } else if (wordCount == 3){
               word3 = word;
            }
         }
         
         System.out.println("[ " + word1 + " ]\t\t\t\t\t[ "+ word2 + "]\t\t\t\t\t[ " + word3 + " ]");
         
         
         if (word1 != word2 && word1 != word3 && word2 != word3){
            System.out.println("You have won $0.");
         } else if ((( word1 == word2) && (word1 != word3 )) || ((word1 == word3) && (word1 != word2)) || ((word2 == word3) && (word2 != word1))){
            System.out.println("You have won " + (userAmountEntered * 2));
         } else {
            System.out.println("You have won " + (userAmountEntered *3));
         }
         System.out.println("Would you like to play again Type 'y' 'yes' 'Y' or 'Yes' for yes, anything else for no.");
         playAgain = keyboard.nextLine();
      }
      System.out.println("Thank you for playing!");
    }
}     
         
            

      
         