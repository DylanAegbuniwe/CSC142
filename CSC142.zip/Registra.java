public class Registra{
   public static void main(String args[]){
     Person a = new Person("Smith", 19);
     Person [] csc530 = {new Person("Kathy", 18), 
        new Person("Martin", 21), new Person("Smith", 19), a};
     }
  }