import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.geometry.*;
import javafx.scene.layout.GridPane;
import javafx.scene.control.TextField;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;
import javax.swing.JOptionPane; 

public class Calculator extends Application
{  
   int num1;
   double answer;
   String strNum1="", strLabel;
   public static void main(String args[])
   {  
      launch();
   }
   public void start(Stage primaryStage)
   {
      //Making Buttons
      Button zero = new Button(" 0 ");
      Button plus = new Button(" + ");
      Button minus = new Button(" - ");
      Button mult = new Button(" x ");   
      Button divide = new Button(" � ");
      Button equal = new Button(" = ");
      Button clear = new Button(" C ");
      Label input1 = new Label("");
      Button [] btn_Number = new Button[9];
      for(int i = 0; i < btn_Number.length; i++)
         btn_Number[i] = new Button(" "+(i+1)+" ");
      
      //design grid
      GridPane grid = new GridPane();
      grid.setMinSize(200,150);
      grid.setPadding(new Insets(10, 10, 10, 10));
      grid.setVgap(10);
      grid.setHgap(10);
            
      //allign grid
      grid.add(zero,1,4);
      for(int i = 0; i <3; i++)
         grid.add(btn_Number[i],i,3);
      for(int i = 3; i <6; i++)
         grid.add(btn_Number[i],(i-3),2);
      for(int i = 6; i <9; i++)
         grid.add(btn_Number[i],(i-6),1);
      grid.add(equal,2,4);
      grid.add(plus,3,4);
      grid.add(minus,3,3);
      grid.add(mult,3,2);
      grid.add(divide,3,1);
      grid.add(clear,0,4);
      grid.add(input1,0,0,4,1);
      
      //create event handlers for num1
      EventHandler<ActionEvent> eZero = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 0; strNum1+= Integer.toString(num1); input1.setText(strNum1);}};           
      EventHandler<ActionEvent> eOne = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 1; strNum1+= Integer.toString(num1); input1.setText(strNum1);}};
      EventHandler<ActionEvent> eTwo = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 2; strNum1+= Integer.toString(num1); input1.setText(strNum1);}};
      EventHandler<ActionEvent> eThree = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 3; strNum1+= Integer.toString(num1); input1.setText(strNum1);}};
      EventHandler<ActionEvent> eFour = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 4; strNum1+= Integer.toString(num1); input1.setText(strNum1);}};
      EventHandler<ActionEvent> eFive = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 5; strNum1+= Integer.toString(num1); input1.setText(strNum1);}};
      EventHandler<ActionEvent> eSix = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 6; strNum1+= Integer.toString(num1); input1.setText(strNum1);}};
      EventHandler<ActionEvent> eSeven = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 7; strNum1+= Integer.toString(num1); input1.setText(strNum1);}};
      EventHandler<ActionEvent> eEight = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 8; strNum1+= Integer.toString(num1); input1.setText(strNum1);}};
      EventHandler<ActionEvent> eNine = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){num1 = 9; strNum1+= Integer.toString(num1); input1.setText(strNum1);}}; 
             
      //event calling
      zero.setOnAction(eZero);
      btn_Number[0].setOnAction(eOne);
      btn_Number[1].setOnAction(eTwo);
      btn_Number[2].setOnAction(eThree);
      btn_Number[3].setOnAction(eFour);
      btn_Number[4].setOnAction(eFive);
      btn_Number[5].setOnAction(eSix);
      btn_Number[6].setOnAction(eSeven);
      btn_Number[7].setOnAction(eEight);
      btn_Number[8].setOnAction(eNine);
      
            
      //event handlers
      EventHandler<ActionEvent> ePlus = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){strLabel =" + "; strNum1 += strLabel; input1.setText(strNum1);}};
      EventHandler<ActionEvent> eMinus = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){strLabel =" - "; strNum1 += strLabel; input1.setText(strNum1);}};
      EventHandler<ActionEvent> eDivide = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){strLabel =" / "; strNum1 += strLabel; input1.setText(strNum1);}};
      EventHandler<ActionEvent> eMultiply = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){strLabel =" x "; strNum1 += strLabel; input1.setText(strNum1);}};
            
      //call symbols
      plus.setOnAction(ePlus);
      minus.setOnAction(eMinus);
      mult.setOnAction(eMultiply);
      divide.setOnAction(eDivide);
      
      //create event handler for equal
      EventHandler<ActionEvent> eEqual = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){ 
               input1.setText("");

               String[] strA;
               strA = strNum1.split(" ");
               if ((strA.length == 2) || (strA[0].length() < 1))
                  input1.setText("Syntax Error: press C to clear.");
               else{
                  switch(strA[1])
                  {
                     case "+": answer = (Double.parseDouble(strA[0]))+(Double.parseDouble(strA[2]));break;
                     case "-": answer = (Double.parseDouble(strA[0]))-(Double.parseDouble(strA[2]));break;
                     case "x": answer = (Double.parseDouble(strA[0]))*(Double.parseDouble(strA[2]));break;
                     case "/": answer = (Double.parseDouble(strA[0]))/(Double.parseDouble(strA[2]));break;
                  }
               input1.setText(Double.toString(answer)); 
               strNum1 = (Double.toString(answer)); 
               }        
            }
      };
      
      //event handler for clear
      EventHandler<ActionEvent> eClear = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e){input1.setText("");strNum1="";}};
            
      clear.setOnAction(eClear);
      equal.setOnAction(eEqual);
      
      //create scene          
      Scene scene = new Scene (grid);      
      grid.setAlignment(Pos.BOTTOM_CENTER);
      primaryStage.setScene(scene);
      primaryStage.setResizable(true);
      primaryStage.setTitle("Calc");
      primaryStage.show();
      }  
}