public class Time implements Comparable {
private int hour =0;
private int minute =0;
public Time (int h, int m){
 if (h<0||h>23) return;
 if(m<0||m>59) return;
 hour = h;
 minute = m;
}
public String toString()
{
   return ("("+hour+","+minute+")");
}

public int getHour() {return hour;}
public int getMinute() {return minute;}

public int compareTo(Object x)
{
   int q = 0, w = 0;
   if ((x != null) && (x instanceof Time))
   {
      Time y = (Time) x;
   q = ((hour*60)+minute);
   w = ((y.getHour()*60)+y.getMinute());
   if (q > w)
      return 1;
   if (q < w)
      return -1;
   if (q == w)
      return 0;
   }
   return -1;
   }
}
         
